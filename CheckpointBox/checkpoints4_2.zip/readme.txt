LSTM

learning_rate = 0.001
num_batches = 1500
batch_size = 1024
display_step = 100
# parameters for LSTM network
n_lstm = 128
lstm_step = 6
seq_length = 20

Seq2Seq

# parameters for traning
learnig_rate = 0.001
num_batches = 1500
batch_size = 1024
display_step = 50
# parameters for seq2seq model
n_lstm = 128
encoder_length = 20
decoder_length = 10


Attention-Seq2Seq (AttentionFunc == 'general' )

# parameters for traning
learnig_rate = 0.001
num_batches = 1500
batch_size = 1024
display_step = 50
# parameters for seq2seq model
n_lstm = 128
encoder_length = 20
decoder_length = 10