Seq2Seq

# parameters for traning
learnig_rate = 0.001
num_batches = 20000
batch_size = 512
display_step = 50
# parameters for seq2seq model
n_lstm = 128
encoder_length = 120
decoder_length = 60

Attention Seq   general

# parameters for traning
learnig_rate = 0.001
num_batches = 400
batch_size = 256
display_step = 50
# parameters for seq2seq model
n_lstm = 128
encoder_length = 120
decoder_length = 60、

都训练3000左右个batch。